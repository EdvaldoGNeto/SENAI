package Atividade8;

public class Questão1 {

	public static void main(String[] args) {
		decimalParaBinario(5);
	}

	private static void decimalParaBinario(int i) {
		if(i>0) {
			decimalParaBinario(i/2);
			System.out.print(i%2);	
		}
	
	}

}
