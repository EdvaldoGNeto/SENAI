package Atividade8;

import java.util.Scanner;

public class Questão3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] numero = new int [2];
		int somatorioimpar=0;
		for(int i = 0; i <numero.length;i++) {
			System.out.println("Digite dois números inteiros: ");
			numero[i] += sc.nextInt();
			if(numero[i] % 2!= 0) {
				somatorioimpar += numero[i];
				if(numero[i]<0) {
					somatorioimpar += numero[i]*-1;
				}
			}
		}
		System.out.println("O Somátorio é igual á "+somatorioimpar);
		sc.close();
	}

}
