package Atividade8;

import java.util.Scanner;

public class Questão2 {

	public static void main(String[] args) {
        String binario= "";
        String binariocontrario = "";
        Scanner sc = new Scanner(System.in);
        System.out.println("Escreva uma frase.");
		binario = sc.next();        
        for (int i = (binario.length()); i != 0; i--) {
            binariocontrario += "" + binario.charAt(i-1);
        }
        System.out.println(binariocontrario);
        sc.close();
	}

}
